###################################
IMPORTANT
###################################

The server running this script must allow external FTP connections
if you intend to allow connection to external servers.

###################################
SUPPORT
###################################

Knowledgebase: http://support.monstahq.com/support/solutions
Contact us: http://support.monstahq.com/support/tickets/new

###################################
INSTALL
###################################

Unzip the contents of the MONSTA Box install zip to your desktop.
Then upload the "mbox" folder (and its contents) to your web space.
You'll then access MONSTA Box in your browser from the URL www.yourdomain.com/mbox 

###################################
UPLOAD LIMITS
###################################

The "Upload Limit" seen on screen is set in your server's PHP.INI file.

###################################
CONFIGURATION
###################################

$ftpHost
Enter the host address/port/mode if it should always be a fixed host 
address. Leave this blank if you want the user to input their host address.

$ftpPort
21 is the default

$ftpMode
1 for passive, 0 for not passive (passive is default)

$ftpSSL
1 for SSL, 0 for not SSL - your server must support ftp_ssl_connect()
 
$ftpDir
Enter an FTP server path for the default login (or leave blank for home)

$serverTmp
This is a folder on the client server for uploading files to.
By default it's /tmp (Linux), which is the server's folder for temporary 
files, however you can set any folder, provided it has 777 chmod 
permissions, so it can be written to from the web. Windows temp folder is 
typically "C:\WINDOWS\Temp\" (backslashes must be escaped with another 
backslash)

$editableExts
A list of file types that can be edited in the text editor

$dateFormatUsa
USA date format - 1 for mm/dd/yy, 0 for dd/mm/yy

$lockOutTime
The number of minutes to lockout 3 consecutive invalid logins

$versionCheck
1 to check Monsta FTP server for updates, 0 to not

$showAdvOption
1 to show advanced interface option at login, 0 to set basic

$showLockSess
1 to show option to lock session to IP, 0 to hide

$showHostInfo
1 to show host address in info box, 0 to hide

$showAddons
1 to show unlicensed addons, 0 to hide

